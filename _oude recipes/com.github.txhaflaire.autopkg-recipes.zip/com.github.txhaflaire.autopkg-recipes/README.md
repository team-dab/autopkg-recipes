# autopkg-recipes
This is a collection of autopkg recipes to just upload into Jamf JSS.
This will upload the PKG file to Jamf only with a category.
Read here how to create these files
https://dazwallace.wordpress.com/2019/03/12/using-autopkg-for-package-uploads-to-jamf-cloud-only/

